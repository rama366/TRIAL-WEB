CREATE TABLE `businesses` (
  `id` int AUTO_INCREMENT NOT NULL,
  `ownerId` int NOT NULL,
  `name` varchar(160) NOT NULL,
  `currency` varchar(8) NOT NULL DEFAULT 'TZS',
  `taxRate` int NOT NULL DEFAULT 18,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `businesses_id` PRIMARY KEY(`id`),
  CONSTRAINT `businesses_owner_idx` INDEX(`ownerId`)
);
--> statement-breakpoint
CREATE TABLE `accounts` (
  `id` int AUTO_INCREMENT NOT NULL,
  `businessId` int NOT NULL,
  `name` varchar(120) NOT NULL,
  `type` enum('cash','bank','mobile_money','card') NOT NULL DEFAULT 'cash',
  `balance` int NOT NULL DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `accounts_id` PRIMARY KEY(`id`),
  CONSTRAINT `accounts_business_idx` INDEX(`businessId`)
);
--> statement-breakpoint
CREATE TABLE `contacts` (
  `id` int AUTO_INCREMENT NOT NULL,
  `businessId` int NOT NULL,
  `name` varchar(160) NOT NULL,
  `type` enum('customer','supplier') NOT NULL DEFAULT 'customer',
  `phone` varchar(32),
  `balance` int NOT NULL DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `contacts_id` PRIMARY KEY(`id`),
  CONSTRAINT `contacts_business_idx` INDEX(`businessId`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
  `id` int AUTO_INCREMENT NOT NULL,
  `businessId` int NOT NULL,
  `accountId` int,
  `contactId` int,
  `kind` enum('income','expense') NOT NULL,
  `amount` int NOT NULL,
  `description` varchar(240) NOT NULL,
  `category` varchar(120) NOT NULL,
  `note` text,
  `occurredAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('cleared','pending','locked') NOT NULL DEFAULT 'cleared',
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
  CONSTRAINT `transactions_business_date_idx` INDEX(`businessId`,`occurredAt`),
  CONSTRAINT `transactions_business_kind_idx` INDEX(`businessId`,`kind`)
);
