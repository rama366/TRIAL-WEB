import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createOwnedTransaction, listOwnedTransactions, summarizeOwnedTransactions } from "./db";
import { invokeLLM } from "./_core/llm";

const transactionInput = z.object({
  businessId: z.number().int().positive().optional(),
  kind: z.enum(["income", "expense"]),
  amount: z.number().int().nonnegative(),
  description: z.string().trim().min(1).max(240),
  category: z.string().trim().min(1).max(120),
  accountId: z.number().int().positive().optional(),
  contactId: z.number().int().positive().optional(),
  note: z.string().trim().max(2000).optional(),
  occurredAt: z.coerce.date().optional(),
  status: z.enum(["cleared", "pending", "locked"]).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  ledger: router({
    list: protectedProcedure.input(z.object({ businessId: z.number().int().positive().optional(), limit: z.number().int().positive().max(250).optional() }).optional()).query(({ ctx, input }) => listOwnedTransactions(ctx.user.id, input?.businessId, input?.limit)),
    summary: protectedProcedure.input(z.object({ businessId: z.number().int().positive().optional() }).optional()).query(({ ctx, input }) => summarizeOwnedTransactions(ctx.user.id, input?.businessId)),
    create: protectedProcedure.input(transactionInput).mutation(({ ctx, input }) => createOwnedTransaction(ctx.user.id, input)),
  }),
  assistant: router({
    ask: protectedProcedure.input(z.object({ question: z.string().trim().min(1).max(500), transactions: z.array(z.object({ kind: z.enum(["income", "expense"]), amount: z.number(), category: z.string(), description: z.string(), date: z.string(), account: z.string(), counterparty: z.string() })).max(500) })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        model: "gpt-5-mini",
        messages: [
          { role: "system", content: "You are Finance Guide inside LedgerLine. Analyze only the provided small-business ledger. Use TZS, be precise, plain-language, and actionable. Never invent a transaction. Explain profit changes using the data. Return JSON only." },
          { role: "user", content: `Question: ${input.question}\nLedger: ${JSON.stringify(input.transactions)}` },
        ],
        maxTokens: 700,
        responseFormat: { type: "json_schema", json_schema: { name: "finance_guide_answer", strict: true, schema: { type: "object", properties: { answer: { type: "string" }, chart: { type: "array", items: { type: "object", properties: { label: { type: "string" }, value: { type: "number" } }, required: ["label", "value"], additionalProperties: false } }, actions: { type: "array", items: { type: "string" } } }, required: ["answer", "chart", "actions"], additionalProperties: false } } },
      });
      const content = response.choices[0]?.message?.content;
      if (typeof content !== "string") throw new Error("Finance Guide returned no text");
      return JSON.parse(content) as { answer: string; chart: Array<{ label: string; value: number }>; actions: string[] };
    }),
  }),
});

export type AppRouter = typeof appRouter;
