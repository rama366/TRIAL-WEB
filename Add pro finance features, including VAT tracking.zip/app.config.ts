export default {
  logoUrl: "https://8328-io381h37r09mbwpt2qgh6-99af8171.us1.manus.computer/favicon.svg",
};
