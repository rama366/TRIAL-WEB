export type TransactionKind = "income" | "expense";

export type Transaction = {
  id: string;
  kind: TransactionKind;
  date: string;
  description: string;
  category: string;
  counterparty: string;
  amount: number;
  account: string;
  initials: string;
  color: string;
  status: "Cleared" | "Pending";
};

export const categories = [
  { name: "Stock / Inventory", color: "#B68B45", icon: "◎" },
  { name: "Transport", color: "#6E8F84", icon: "↗" },
  { name: "Salaries", color: "#8E6A82", icon: "∿" },
  { name: "Utilities", color: "#6D7E9A", icon: "⌁" },
  { name: "Marketing", color: "#A97C64", icon: "✦" },
  { name: "Taxes", color: "#A55E5A", icon: "%" },
  { name: "Supplies", color: "#7E8C70", icon: "□" },
  { name: "Rent", color: "#7C6C58", icon: "⌂" },
];

// Canonical October 2026 demo ledger. Income = TZS 9.4m; expenses = TZS 5.2m; net profit = TZS 4.2m.
export const demoTransactions: Transaction[] = [
  { id: "TX-1058", kind: "income", date: "30 Oct, 14:20", description: "Wholesale order · INV-207", category: "Wholesale", counterparty: "Kijitonyama Office", amount: 1380000, account: "NMB Business", initials: "KO", color: "#8E6A82", status: "Cleared" },
  { id: "TX-1057", kind: "expense", date: "30 Oct, 09:10", description: "Month-end stock restock", category: "Stock / Inventory", counterparty: "Mlimani Wholesale", amount: 820000, account: "NMB Business", initials: "MW", color: "#B68B45", status: "Cleared" },
  { id: "TX-1056", kind: "income", date: "29 Oct, 16:45", description: "Counter sales · weekend", category: "Retail sales", counterparty: "Walk-in customers", amount: 920000, account: "M-Pesa Till", initials: "WS", color: "#2E7755", status: "Cleared" },
  { id: "TX-1055", kind: "expense", date: "29 Oct, 11:30", description: "September payroll", category: "Salaries", counterparty: "Team payroll", amount: 1248000, account: "NMB Business", initials: "TP", color: "#8E6A82", status: "Cleared" },
  { id: "TX-1054", kind: "income", date: "26 Oct, 13:05", description: "Invoice #INV-204 paid", category: "Wholesale", counterparty: "Maua Café", amount: 820000, account: "NMB Business", initials: "MC", color: "#2E7755", status: "Cleared" },
  { id: "TX-1053", kind: "expense", date: "25 Oct, 15:20", description: "Delivery runs · Kinondoni", category: "Transport", counterparty: "Juma Logistics", amount: 728000, account: "Cash on hand", initials: "JL", color: "#6E8F84", status: "Cleared" },
  { id: "TX-1052", kind: "income", date: "22 Oct, 18:10", description: "Retail sales · M-Pesa", category: "Retail sales", counterparty: "Walk-in customers", amount: 1860000, account: "M-Pesa Till", initials: "WS", color: "#2E7755", status: "Cleared" },
  { id: "TX-1051", kind: "expense", date: "20 Oct, 10:00", description: "TANESCO and water bills", category: "Utilities", counterparty: "TANESCO", amount: 572000, account: "NMB Business", initials: "TN", color: "#6D7E9A", status: "Cleared" },
  { id: "TX-1050", kind: "income", date: "15 Oct, 12:40", description: "Retail sales · market week", category: "Retail sales", counterparty: "Walk-in customers", amount: 2140000, account: "M-Pesa Till", initials: "WS", color: "#2E7755", status: "Cleared" },
  { id: "TX-1049", kind: "expense", date: "12 Oct, 09:15", description: "Store supplies and packaging", category: "Other", counterparty: "Mlimani Supplies", amount: 676000, account: "Cash on hand", initials: "MS", color: "#D6CFC1", status: "Pending" },
  { id: "TX-1048", kind: "income", date: "08 Oct, 10:42", description: "Counter sale · 14 items", category: "Retail sales", counterparty: "Walk-in customers", amount: 2280000, account: "M-Pesa Till", initials: "WS", color: "#2E7755", status: "Cleared" },
  { id: "TX-1047", kind: "expense", date: "05 Oct, 08:15", description: "Inventory delivery and restock", category: "Stock / Inventory", counterparty: "Mlimani Wholesale", amount: 1156000, account: "NMB Business", initials: "MW", color: "#B68B45", status: "Cleared" },
];

export const monthlyTrend = [
  { month: "Apr", income: 6.2, expense: 3.9, profit: 2.3 },
  { month: "May", income: 7.1, expense: 4.3, profit: 2.8 },
  { month: "Jun", income: 6.8, expense: 4.1, profit: 2.7 },
  { month: "Jul", income: 8.4, expense: 4.9, profit: 3.5 },
  { month: "Sep", income: 8.8, expense: 5.1, profit: 3.7 },
  { month: "Oct", income: 9.4, expense: 5.2, profit: 4.2 },
];

export const weeklyTrend = [
  { month: "Mon", income: 1.05, expense: 0.54, profit: 0.51 },
  { month: "Tue", income: 1.32, expense: 0.62, profit: 0.70 },
  { month: "Wed", income: 1.18, expense: 0.73, profit: 0.45 },
  { month: "Thu", income: 1.46, expense: 0.68, profit: 0.78 },
  { month: "Fri", income: 1.72, expense: 0.83, profit: 0.89 },
  { month: "Sat", income: 2.08, expense: 0.90, profit: 1.18 },
  { month: "Sun", income: 0.59, expense: 0.90, profit: -0.31 },
];

export const expenseMix = [
  { name: "Inventory", category: "Stock / Inventory", amount: 1976000, value: 38, color: "#B68B45" },
  { name: "Payroll", category: "Salaries", amount: 1248000, value: 24, color: "#285347" },
  { name: "Transport", category: "Transport", amount: 728000, value: 14, color: "#6E8F84" },
  { name: "Utilities", category: "Utilities", amount: 572000, value: 11, color: "#6D7E9A" },
  { name: "Other", category: "Other", amount: 676000, value: 13, color: "#D6CFC1" },
];

export const budgets = [
  { name: "Stock / Inventory", spent: 1976000, budget: 2400000, color: "#B68B45" },
  { name: "Transport", spent: 728000, budget: 850000, color: "#6E8F84" },
  { name: "Utilities", spent: 572000, budget: 650000, color: "#6D7E9A" },
  { name: "Salaries", spent: 1248000, budget: 1400000, color: "#8E6A82" },
];

export const contacts = [
  { name: "Maua Café", type: "Customer", balance: 1280000, detail: "Last sale 26 Oct · 4 invoices", initials: "MC", color: "#8E6A82" },
  { name: "Mlimani Wholesale", type: "Supplier", balance: -420000, detail: "Last purchase 30 Oct · Net 14", initials: "MW", color: "#B68B45" },
  { name: "Zuri Guesthouse", type: "Customer", balance: 640000, detail: "Last sale 22 Sep · 2 invoices", initials: "ZG", color: "#2E7755" },
  { name: "Juma Logistics", type: "Supplier", balance: -34000, detail: "Last payment 29 Sep", initials: "JL", color: "#6E8F84" },
];

export const accountBalances = [
  { name: "M-Pesa Till", type: "Mobile money", balance: 1840000 },
  { name: "Airtel Money", type: "Mobile money", balance: 620000 },
  { name: "NMB Business", type: "Bank account", balance: 1980000 },
  { name: "Cash on hand", type: "Cash", balance: 420000 },
];

export const VAT_RATE = 0.18;

export function calculateVat(transactions: Transaction[]) {
  const taxableSales = transactions.filter(t => t.kind === "income").reduce((sum, t) => sum + t.amount, 0);
  const taxablePurchases = transactions.filter(t => t.kind === "expense").reduce((sum, t) => sum + t.amount, 0);
  const collected = Math.round(taxableSales * VAT_RATE);
  const paid = Math.round(taxablePurchases * VAT_RATE);
  return { taxableSales, taxablePurchases, collected, paid, owed: collected - paid };
}

export function profitAndLoss(transactions: Transaction[]) {
  const summary = summarize(transactions);
  const costOfGoodsSold = transactions.filter(t => t.kind === "expense" && t.category === "Stock / Inventory").reduce((sum, t) => sum + t.amount, 0);
  const grossProfit = summary.income - costOfGoodsSold;
  const operatingExpenses = summary.expenses - costOfGoodsSold;
  return { ...summary, costOfGoodsSold, grossProfit, operatingExpenses, netProfit: grossProfit - operatingExpenses };
}

export function octoberCalendarDays() {
  const first = new Date(2026, 9, 1);
  const daysInMonth = new Date(2026, 10, 0).getDate();
  const leadingBlanks = first.getDay(); // Thursday = 4; Sunday-first calendar.
  return Array.from({ length: leadingBlanks + daysInMonth }, (_, index) => index < leadingBlanks ? null : index - leadingBlanks + 1);
}

export const formatTZS = (value: number, compact = false) => {
  if (compact) {
    if (Math.abs(value) >= 1000000) return `TZS ${(value / 1000000).toFixed(1)}m`;
    if (Math.abs(value) >= 1000) return `TZS ${Math.round(value / 1000)}k`;
  }
  return new Intl.NumberFormat("en-TZ", { style: "currency", currency: "TZS", maximumFractionDigits: 0 }).format(value);
};

export function summarize(transactions: Transaction[]) {
  const income = transactions.filter(t => t.kind === "income").reduce((sum, t) => sum + t.amount, 0);
  const expenses = transactions.filter(t => t.kind === "expense").reduce((sum, t) => sum + t.amount, 0);
  const profit = income - expenses;
  return { income, expenses, profit, margin: income ? (profit / income) * 100 : 0 };
}

export function healthScore(summary: ReturnType<typeof summarize>) {
  const marginScore = Math.min(35, Math.max(8, summary.margin * 0.8));
  const growthScore = summary.income > 0 ? 26 : 8;
  const cashScore = Math.min(21, summary.profit > 0 ? 19 : 7);
  const debtScore = 10;
  return Math.round(marginScore + growthScore + cashScore + debtScore);
}
