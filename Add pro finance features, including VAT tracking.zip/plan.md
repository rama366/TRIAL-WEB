# LedgerLine implementation plan

## Goal and product shape

Build **LedgerLine**, a responsive, installable small-business finance workspace for a Dar es Salaam shop using **TZS** by default. The first delivered slice will be a polished, navigable product rather than a thin marketing mock: a usable dashboard with realistic demo data, core income/expense flows, reports, business health, quick POS capture, customer/supplier context, VAT/tax visibility, and the public landing/help surfaces requested in the brief.

The initialized project is a managed React/Express/tRPC/Drizzle web project at `/home/ubuntu/ledgerline`, with Server and managed Database enabled. The starter currently has a single Home route, an auth router, and only the `users` table; the implementation will extend those existing seams instead of replacing the scaffold.

## Scope and implementation decisions

### Core experience to make real in the first release

- Public landing page at `/` with product positioning, feature sections, dashboard preview, pricing cards (Free / Pro / Business), testimonials, FAQ, and clear CTA into the app.
- Auth-aware app shell at `/app` with desktop sidebar and mobile bottom navigation for Dashboard, Income, Expenses, Reports, and Settings.
- Dashboard with period switcher (This Week / This Month / This Year / Custom Range), KPI cards for Total Income, Total Expenses, Net Profit, Gross Profit, Profit Margin, and Cash Balance; trend comparisons; income-vs-expenses bars; profit trend line; expense-category donut; health KPIs; budget progress; upcoming bills; recent transactions; and a floating quick-add action.
- Income and expense entry screens with date, amount, customer/vendor, category, payment method, account, tags, notes, receipt placeholder/upload affordance, recurring toggle, and bulk-import entry point. Demo-mode OCR will be represented by a clear scan affordance and parsed-preview state rather than claiming a live OCR result without a configured provider.
- Reports screen with P&L, cash flow, tax summary, category/source views, YoY comparison, period controls, and export/print affordances. Exports will be wired to stable client/server seams and use demo data until file generation is configured.
- Business Health Score (0–100) with the requested dimensions: margin, cash runway, debt, and expense growth; include simple next-step advice.
- Customers & Suppliers directory with balances, history summaries, and visible WhatsApp/call actions.
- Quick POS screen with product, quantity, discount, payment method, receipt preview, and share action.
- VAT/tax mode with collected VAT, paid VAT, and amount owed; adjustable tax rate in settings.
- Multi-business/branch selector with combined/separate view state in the shell, month-end closing action and lock indicator, customizable dashboard widget order via drag affordances, theme toggle, language toggle, notifications/help center entry points, and Google Sheets/QuickBooks export affordances.
- Demo “AI Finance Guide” chat panel that answers against the visible demo dataset in plain language and can switch to chart-ready suggestions. The code will use a server seam compatible with the platform LLM contract when enabled, with a helpful local fallback for the first release.
- Responsive and accessible behavior: 44–48px minimum touch targets, stacked transaction cards on narrow screens, dark mode, keyboard-focus states, tooltips, and progressive disclosure.

### Staged / integration-dependent behavior

The UI will clearly distinguish demo-ready workflows from integrations that need provider credentials or production jobs. Real Manus OAuth/session handling will be preserved from the starter and protected routes will use the starter’s auth conventions. Database-backed tables and tRPC procedures will be added for transactions, categories, accounts, contacts, budgets, goals, and business settings. The following will be surfaced with honest states and implementation seams rather than fabricated completion: live M-Pesa/Tigo Pesa/Airtel/bank parsing, production OCR, WhatsApp/SMS delivery, scheduled recurring jobs, external Google Sheets/QuickBooks authorization, true offline conflict-free sync, 2FA, and subscription billing.

## Design system

- **Design movement:** Quiet luxury editorial finance UI, inspired by private-banking statements and modern East African business ledgers.
- **Core principles:** calm density, high-trust hierarchy, restrained ornament, and immediate decision support.
- **Color philosophy:** warm ivory reduces the visual fatigue of dense financial data; deep navy grounds trust; brass/gold marks important boundaries and earned progress; forest and muted red communicate profit/loss without loud gamification.
- **Palette:** ivory `#F7F4EE`, ink `#17211F`, navy `#132B35`, forest `#285347`, brass `#B68B45`, pale brass `#E8D7B6`, profit `#2E7755`, loss `#A55E5A`, muted slate `#68736F`.
- **Layout paradigm:** a “ledger rail” composition: a persistent left navigation spine on desktop, wide editorial content canvas, and data panels arranged asymmetrically around a primary financial narrative rather than a uniform dashboard grid. Mobile collapses the rail into a bottom action bar.
- **Signature elements:** thin brass ledger rules, a monogram-style `LL` mark built from two offset vertical strokes, and small uppercase period labels paired with large serif values.
- **Interaction philosophy:** every control should explain its financial consequence; quick actions use one decisive step, detail panels reveal on demand, and irreversible actions (closing a month, deleting entries) are visually gated.
- **Animation:** 160–220ms ease-out fades/slides for panels and route transitions; number changes gently count up; charts draw in on first view; drag states use a soft brass lift and never bounce or distract from figures.
- **Typography:** Playfair Display for headings, values, and section titles; Inter for body, labels, tables, and controls. Use tabular numerals for money and percentages.
- **Brand essence:** “A clearer ledger for the work behind the business.” Personality: assured, warm, practical.
- **Brand voice:** concise, respectful, financially literate without jargon. Example lines: “Know what the month is really keeping.” and “Your transport spend is climbing. Here is where to look next.”
- **Wordmark/logo:** `LedgerLine` in a refined serif with a two-stroke `LL` mark that resembles a ledger spine and a rising line; use the mark in the sidebar and favicon/app metadata.
- **Signature brand color:** brass `#B68B45`, used sparingly for ledger rules, selected states, and primary focus.

## Project structure and key changes

- `client/src/App.tsx`: add the public/app route map and shared providers; keep the existing error, theme, tooltip, and toaster providers.
- `client/src/index.css` and Tailwind/theme tokens: establish ivory/navy/forest/brass tokens, light/dark modes, serif/sans typography, focus rings, responsive spacing, and table/card primitives.
- `client/src/components/ledgerline/`: shared app shell, sidebar, mobile bottom nav, KPI card, chart panels, transaction row/card, period switcher, health score, quick-add modal, chat panel, command/search surface, and empty/loading/error states.
- `client/src/pages/`: `Landing`, `Dashboard`, `Income`, `Expenses`, `Reports`, `Budgets`, `Debts`, `Inventory`, `Invoices`, `Accounts`, `Calendar`, `Contacts`, `Pos`, `Notifications`, `HelpCenter`, and `Settings`, plus `NotFound`.
- `client/src/lib/`: demo data, currency/locale helpers, financial calculations, export helpers, route constants, and future offline queue contracts.
- `server/routers.ts`: add protected procedures for dashboard summaries, transactions CRUD, reports, contacts, budgets/goals, accounts/settings, and assistant prompts; keep public/auth routers intact.
- `server/db.ts` and `drizzle/schema.ts`: add project-scoped business entities with user ownership/business/branch keys, transaction indexes, status/lock fields, timestamps, and audit-friendly metadata. Add additive migrations only; do not destroy starter user data.
- `server/_core/index.ts` and adjacent helpers: preserve health/auth behavior, add only the minimal REST callback/export endpoints needed by the UI, and keep sensitive responses `Cache-Control: no-store`.
- `public/manus-routes.json`: declare every page route served by the app before starting Preview. Add `public/manifest.webmanifest`, icons/brand metadata, and a service-worker shell with a pending-sync indicator contract; sensitive finance pages will not be cached.
- `app.config.ts`: add a quoted durable HTTPS `logoUrl` literal for the LedgerLine mark before checkpointing.

## Build sequence

1. **Foundation:** inspect the existing starter files, register host-managed TypeScript diagnostics, add the route manifest, design tokens, fonts, logo mark, theme switching, demo data, and responsive app shell.
2. **Dashboard:** implement the first-open demo experience with all requested KPIs/charts/insights, period state, health score, budgets, bills, recent transactions, customizable widget controls, and quick-add.
3. **Core ledger workflows:** implement income/expense forms, transaction list/filtering, recurring/bulk-import affordances, category/account selectors, and POS/receipt flow with local UI state connected to tRPC seams.
4. **Reports and tax:** implement report tabs, P&L/cash-flow/tax summaries, VAT collected/paid/owed, export/print affordances, and month-end close/lock states.
5. **Relationships and support surfaces:** implement contacts directory, debts/goals, notifications, help center/tooltips, AI assistant panel, landing page, pricing/testimonials/FAQ, and settings.
6. **Persistence and hardening:** add Drizzle schema/migrations/procedures for the core entities; seed safe demo records only when the current user/business is empty; preserve auth and ownership boundaries; add PWA manifest/service worker behavior and responsive accessibility polish.

## Verification plan

- Run `pnpm check` and `pnpm test` after implementation; add focused calculation tests for profit, margin, VAT owed, health score, and period aggregation.
- Start the project with `pnpm dev` on the configured port and verify the server returns the app shell and `/api/health`.
- Request `/manus-routes.json` and confirm HTTP 200 plus a route set matching the source routes, with no API/assets/404-only entries.
- Inspect runtime diagnostics after edits and resolve actionable TypeScript errors; do not treat a running LSP alone as clean.
- Use Webdev Preview screenshots for desktop and mobile to verify the landing page, dashboard, and a form/report route; check dark mode and narrow-width stacked transaction behavior.
- Trace key source paths from shell → tRPC → database schema for dashboard, transaction save, report aggregation, and month-close lock; verify no sensitive financial data is embedded in URLs.
- Commit the intended files to the project’s canonical `main` branch, confirm the checkpoint SHA, and only then provide the Preview URL unless a successful publish is explicitly completed.

## Assumptions and open risks

- The brief is intentionally broad, so the first delivery prioritizes a cohesive, high-fidelity core release over pretending every external integration is production-ready.
- The initialized database is MySQL-compatible despite the brief naming PostgreSQL; the implementation will use the selected managed resource and Drizzle/MySQL starter conventions.
- Real WhatsApp/SMS, bank/mobile-money connectors, OCR, export file generation, recurring jobs, and external OAuth providers need credentials/provider contracts not present in the brief; they will be represented with honest UI states and server seams until configured.
- Subscription pricing is a marketing surface only in this pass; no billing or payment flow will be enabled without an explicit provider decision.
- If the existing project has remote/concurrent changes when code work begins, preserve them and integrate rather than overwrite.
